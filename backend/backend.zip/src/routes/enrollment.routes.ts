// src/routes/enrollment.routes.ts
import express from "express";
import { authenticateUser } from "../middlewares/auth";
import { 
  createEnrollment, 
  getUserEnrollments, 
  verifyPayment, 
  updateEnrollmentProgress,
  updateModuleProgress,
  updateFinalAssessment,
  updateProgress
} from "../controllers/enrollment.controller";
import { getEnrollmentProgress } from "../controllers/enrollment.controller";
import {
  startCourseHandler,
  viewLessonHandler,
  completeLessonNoQuizHandler,
  submitQuizHandler
} from '../controllers/courseProgress.controller';

const router = express.Router();

// User enrollment routes
router.post("/", authenticateUser, createEnrollment);
router.get("/my-courses", authenticateUser, getUserEnrollments);
router.patch("/:enrollmentId/progress", authenticateUser, updateEnrollmentProgress);
router.post("/:enrollmentId/update-lesson", authenticateUser, updateProgress);

// Course progress flow endpoints
router.post('/:enrollmentId/start', authenticateUser, startCourseHandler);
router.post('/:enrollmentId/lessons/:lessonId/view', authenticateUser, viewLessonHandler);
router.post('/:enrollmentId/lessons/:lessonId/complete', authenticateUser, completeLessonNoQuizHandler);
router.post('/:enrollmentId/quizzes/:quizId/submit', authenticateUser, submitQuizHandler);
router.get('/:enrollmentId/progress', authenticateUser, getEnrollmentProgress);

// New endpoint for updating module progress
router.post("/update-module-progress", authenticateUser, updateModuleProgress);
router.post("/update-final-assessment", authenticateUser, updateFinalAssessment);


export default router;
