import { Request, Response } from 'express';
import { AuthRequest } from '../middlewares/auth';
import * as service from '../services/courseProgressService';

export const startCourseHandler = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    const { enrollmentId } = req.params;
    await service.startCourse(enrollmentId, req.user.id);
    res.json({ message: 'Course started' });
  } catch (err: any) {
    console.error('startCourseHandler error', err);
    res.status(500).json({ error: err.message || 'Failed to start course' });
  }
};

export const viewLessonHandler = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    const { enrollmentId, lessonId } = req.params;
    const lp = await service.viewLesson(enrollmentId, req.user.id, lessonId);
    res.json({ message: 'Lesson viewed', lessonProgress: lp });
  } catch (err: any) {
    console.error('viewLessonHandler error', err);
    const msg = err?.message || '';
    if (msg.includes('Progress not found') || msg.includes('not found')) { res.status(404).json({ error: msg }); return; }
    if (msg.includes('not owned') || msg.includes('invalid enrollment')) { res.status(403).json({ error: msg }); return; }
    if (msg.includes('locked') || msg.includes('Lesson is locked')) { res.status(409).json({ error: msg }); return; }
    if (msg.includes('Lesson progress')) { res.status(422).json({ error: msg }); return; }
    res.status(500).json({ error: err.message || 'Failed to view lesson' });
  }
};

export const completeLessonNoQuizHandler = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    const { enrollmentId, lessonId } = req.params;
    const lp = await service.completeLessonNoQuiz(enrollmentId, req.user.id, lessonId);
    res.json({ message: 'Lesson completed', lessonProgress: lp });
  } catch (err: any) {
    console.error('completeLessonNoQuizHandler error', err);
    // Map common domain errors to 4xx responses for clearer client handling
    const msg = err?.message || '';
    if (msg.includes('not found')) { res.status(404).json({ error: msg }); return; }
    if (msg.includes('not owned') || msg.includes('invalid enrollment')) { res.status(403).json({ error: msg }); return; }
    if (msg.includes('locked') || msg.includes('Lesson is locked')) { res.status(409).json({ error: msg }); return; }
    if (msg.includes('Lesson progress')) { res.status(422).json({ error: msg }); return; }
    res.status(500).json({ error: err.message || 'Failed to complete lesson' });
  }
};

export const submitQuizHandler = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    const { enrollmentId, quizId } = req.params;
    const answers = req.body.answers;
    const result = await service.submitQuiz(enrollmentId, req.user.id, quizId, answers);
    res.json({ message: 'Quiz submitted', result });
  } catch (err: any) {
    console.error('submitQuizHandler error', err);
    res.status(500).json({ error: err.message || 'Failed to submit quiz' });
  }
};
