import { startCourse, viewLesson, completeLessonNoQuiz, submitQuiz, completeModuleAssessment, ensureProgress } from '../services/courseProgressService';
import { Request, Response } from "express";
import axios from "axios";
import { randomUUID } from "crypto";
import { prisma } from "../lib/prisma";
import { AuthRequest } from "../middlewares/auth";

const courseInclude = { course: { include: { instructor: { select: { name: true } }, category: true } } };

export const createEnrollment = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) { res.status(401).json({ error: "Unauthorized - Please log in" }); return; }
    const { courseId, paymentMethod, paymentReference } = req.body;
    const course = await prisma.course.findUnique({ where: { id: courseId } });
    if (!course) { res.status(404).json({ error: "Course not found" }); return; }
    const existing = await prisma.enrollment.findUnique({ where: { userId_courseId: { userId: req.user.id, courseId } } });
    if (existing) { res.status(409).json({ error: "You are already enrolled in this course", enrollment: existing }); return; }
    if (course.isFree) {
      const enrollment = await prisma.enrollment.create({ data: { userId: req.user.id, courseId, paymentStatus: "WAIVED" } });
      res.status(201).json({ message: "Enrollment successful", enrollment }); return;
    }
    if (!paymentMethod || !paymentReference) { res.status(400).json({ error: "Payment method and reference are required" }); return; }
    if (paymentMethod === "PAYSTACK") {
      const secret = process.env.PAYSTACK_SECRET;
      if (!secret) { res.status(500).json({ error: "PAYSTACK_SECRET is not configured" }); return; }
      const result = await axios.get(`https://api.paystack.co/transaction/verify/${paymentReference}`, { headers: { Authorization: `Bearer ${secret}` } });
      if (result.data?.data?.status !== "success") { res.status(400).json({ error: "Payment verification failed" }); return; }
    }
    const enrollment = await prisma.enrollment.create({ data: { userId: req.user.id, courseId, paymentMethod: String(paymentMethod).toUpperCase() as any, paymentReference, paymentStatus: paymentMethod === "BANK_TRANSFER" ? "PENDING" : "PAID" } });
    res.status(201).json({ message: paymentMethod === "BANK_TRANSFER" ? "Transfer reference received; awaiting verification" : "Payment verified and enrollment successful", enrollment });
  } catch (error) { console.error("Enrollment error:", error); res.status(500).json({ error: "Failed to create enrollment" }); }
};

export const getUserEnrollments = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) { res.status(401).json({ error: "Unauthorized" }); return; }
    const enrollments = await prisma.enrollment.findMany({ where: { userId: req.user.id }, include: courseInclude, orderBy: { createdAt: "desc" } });
    res.json(enrollments.map((enrollment) => ({ _id: enrollment.id, userId: enrollment.userId, courseId: enrollment.course ? { _id: enrollment.course.id, title: enrollment.course.title } : undefined, status: enrollment.status, paymentStatus: enrollment.paymentStatus, paymentMethod: enrollment.paymentMethod || undefined, paymentReference: enrollment.paymentReference || undefined, createdAt: enrollment.createdAt, progressPercentage: enrollment.progressPercentage })));
  } catch (error) { console.error("Error fetching enrollments:", error); res.status(500).json({ error: "Error fetching enrollments" }); }
};

export const verifyPayment = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user || String(req.user.role).toUpperCase() !== "ADMIN") { res.status(403).json({ error: "Unauthorized - Admin access required" }); return; }
    const { verified } = req.body;
    const enrollment = await prisma.enrollment.update({ where: { id: req.params.enrollmentId || req.params.id }, data: { paymentStatus: verified ? "PAID" : "NOT_PAID", status: verified ? "ENROLLED" : undefined } });
    res.json({ message: `Payment ${verified ? "verified" : "rejected"} successfully`, enrollment });
  } catch { res.status(404).json({ error: "Enrollment not found" }); }
};

export const updateEnrollmentProgress = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) { res.status(401).json({ error: "Unauthorized" }); return; }
    const progress = Number(req.body.progress);
    if (progress < 0 || progress > 100) { res.status(400).json({ error: "Valid progress percentage (0-100) is required" }); return; }
    const existing = await prisma.enrollment.findFirst({ where: { id: req.params.enrollmentId, userId: req.user.id } });
    if (!existing) { res.status(404).json({ error: "Enrollment not found or not owned by user" }); return; }
    const enrollment = await prisma.enrollment.update({ where: { id: existing.id }, data: { progressPercentage: progress, status: progress >= 100 ? "COMPLETED" : progress > 0 ? "IN_PROGRESS" : "ENROLLED" } });
    res.json({ message: "Progress updated successfully", enrollment });
  } catch { res.status(500).json({ error: "Failed to update progress" }); }
};

export const updateModuleProgress = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) { res.status(401).json({ error: "Unauthorized" }); return; }
    const enrollment = await prisma.enrollment.findFirst({ where: { userId: req.user.id, courseId: req.body.courseId } });
    if (!enrollment) { res.status(404).json({ error: "Enrollment not found or not owned by user" }); return; }
    const result = await completeModuleAssessment(enrollment.id, req.user.id, req.body.moduleId, Boolean(req.body.assessmentPassed), req.body.score);
    res.json({ message: "Module progress updated", moduleProgress: result });
  } catch (error: any) { res.status(error.message?.includes("not found") ? 404 : 409).json({ error: error.message || "Failed to update module progress" }); }
};

export const updateFinalAssessment = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) { res.status(401).json({ error: "Unauthorized" }); return; }
    const enrollment = await prisma.enrollment.findFirst({ where: { userId: req.user.id, courseId: req.body.courseId } });
    if (!enrollment) { res.status(404).json({ error: "Enrollment not found" }); return; }
    const passed = Number(req.body.finalScore) >= Number(req.body.passingScore || 70);
    const certificate = passed ? { id: randomUUID(), issuedAt: new Date(), downloadUrl: `/certificates/${enrollment.id}.pdf` } : undefined;
    const updated = await prisma.enrollment.update({ where: { id: enrollment.id }, data: { finalAssessmentPassed: passed, finalScore: Number(req.body.finalScore), status: passed ? "COMPLETED" : enrollment.status, certificate } });
    res.json({ message: passed ? "Final assessment passed. Certificate generated." : "Final assessment not passed. Please try again.", enrollment: updated });
  } catch { res.status(500).json({ error: "Failed to update final assessment" }); }
};

export const getEnrollmentProgress = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    if (!req.user) { res.status(401).json({ error: "Unauthorized" }); return; }
    const enrollment = await prisma.enrollment.findFirst({ where: { id: req.params.enrollmentId, userId: req.user.id }, include: { course: { include: { modules: { orderBy: { order: "asc" }, include: { lessons: { orderBy: { order: "asc" } } } } } }, courseProgress: true } });
    if (!enrollment) { res.status(404).json({ error: "Enrollment not found or not owned by user" }); return; }
    if (!enrollment.courseProgress) { await startCourse(enrollment.id, req.user.id); }
    const state = await ensureProgress(enrollment.id, req.user.id);
    res.json({ enrollmentId: enrollment.id, status: enrollment.status, progressPercentage: enrollment.progressPercentage, modules: state.modules });
  } catch (error) { console.error(error); res.status(500).json({ error: "Failed to fetch enrollment progress" }); }
};

export const updateProgress = async (req: Request, res: Response): Promise<void> => {
  try {
    const enrollment = await prisma.enrollment.findUnique({ where: { id: req.params.enrollmentId } });
    if (!enrollment) { res.status(404).json({ error: "Enrollment not found" }); return; }
    const current: any[] = Array.isArray(enrollment.progress) ? enrollment.progress as any[] : [];
    const module = current.find((item) => String(item.moduleId) === String(req.body.moduleId));
    if (module) { const lesson = module.lessons.find((item: any) => String(item.lessonId) === String(req.body.lessonId)); if (lesson) lesson.completed = Boolean(req.body.completed); else module.lessons.push({ lessonId: req.body.lessonId, completed: Boolean(req.body.completed) }); }
    else current.push({ moduleId: req.body.moduleId, lessons: [{ lessonId: req.body.lessonId, completed: Boolean(req.body.completed) }], completed: false });
    const updated = await prisma.enrollment.update({ where: { id: enrollment.id }, data: { progress: current } });
    res.json(updated);
  } catch { res.status(500).json({ error: "Failed to update progress" }); }
};
