import { Request, Response } from "express";
import axios from "axios";
import { prisma } from "../lib/prisma";
import { AuthRequest } from "../middlewares/auth";

const courseInclude = {
  instructor: { select: { id: true, name: true, title: true, avatar: true, isAvailableForCall: true, locale: true, currency: true } },
  category: true,
  modules: { orderBy: { order: "asc" as const }, include: { lessons: { orderBy: { order: "asc" as const } } } },
};

const categoryIdFor = async (category: unknown) => {
  const value = String(category || "Uncategorized");
  const existing = await prisma.category.findFirst({ where: { OR: [{ id: value }, { name: value }] } });
  return existing?.id || (await prisma.category.create({ data: { name: value } })).id;
};

const shapeCourseResponse = (course: any, progress = 0) => ({
  id: course.id,
  _id: course.id,
  title: course.title,
  description: course.description,
  status: course.status || "DRAFT",
  publishAt: course.publishAt || null,
  instructor: course.instructor,
  category: course.category?.name || course.category,
  price: course.price,
  enrolledStudents: course.enrolledStudents || [],
  isFree: course.isFree,
  modules: course.modules || [],
  thumbnail: course.thumbnail || "/images/course-default.jpg",
  level: course.level || "Beginner",
  duration: course.duration || "0 hours",
  progress,
  finalAssessment: course.finalAssessment ?? null,
});

const moduleData = (module: any, index: number) => ({
  title: module.title,
  description: module.description || "",
  order: typeof module.order === "number" ? module.order : index,
  assessment: module.assessment ?? null,
  lessons: { create: Array.isArray(module.lessons) ? module.lessons.map((lesson: any, lessonIndex: number) => ({
    title: lesson.title,
    description: lesson.description || "",
    lessonType: lesson.lessonType || "text-only",
    content: lesson.content || "",
    videoUrl: lesson.videoUrl || null,
    duration: lesson.duration || null,
    order: typeof lesson.order === "number" ? lesson.order : lessonIndex,
    hasQuiz: Boolean(lesson.hasQuiz),
  })) : [] },
});

export const createCourse = async (req: Request, res: Response) => {
  try {
    const { title, description, instructor, category, price, isFree, modules = [], thumbnail, duration, level, finalAssessment } = req.body;
    const instructorId = instructor || (req as AuthRequest).user?.id;
    if (!instructorId) return res.status(400).json({ error: "Instructor is required" });
    const categoryId = await categoryIdFor(category);
    const course = await prisma.course.create({
      data: { slug: `${String(title).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "")}-${Date.now()}`, title, description, instructorId, categoryId, price: Number(price || 0), isFree: Boolean(isFree), thumbnail, duration: duration || "0 hours", level: level || "Beginner", finalAssessment: finalAssessment || null, modules: { create: modules.map(moduleData) } },
      include: courseInclude,
    });
    res.status(201).json({ message: "Course created successfully", course: shapeCourseResponse(course) });
  } catch (error) { console.error("Course creation error:", error); res.status(500).json({ error: "Failed to create course" }); }
};

export const importCourse = createCourse;

export const getCourseById = async (req: Request, res: Response) => {
  try {
    const course = await prisma.course.findUnique({ where: { id: req.params.courseId }, include: courseInclude });
    if (!course) return res.status(404).json({ error: "Course not found" });
    res.json(shapeCourseResponse(course));
  } catch (error) { console.error("Error fetching course:", error); res.status(500).json({ error: "Failed to fetch course details" }); }
};

export const getCourses = async (req: AuthRequest, res: Response) => {
  try {
    const { instructor, status } = req.query as { instructor?: string; status?: string };
    const instructorId = instructor || (req.user?.role?.toUpperCase() === "INSTRUCTOR" ? req.user.id : undefined);
    const courses = await prisma.course.findMany({ where: { instructorId, status: status?.toUpperCase() as any }, orderBy: { createdAt: "desc" }, include: courseInclude });
    res.json(courses.map((course) => shapeCourseResponse(course)));
  } catch (error) { console.error("Error fetching courses:", error); res.status(500).json({ error: "Failed to fetch courses" }); }
};

export const enrollInCourse = async (req: Request, res: Response) => {
  try {
    const { courseId, reference, paymentMethod } = req.body;
    const userId = (req as AuthRequest).user?.id;
    if (!userId) return res.status(401).json({ error: "Unauthorized" });
    const course = await prisma.course.findUnique({ where: { id: courseId } });
    if (!course) return res.status(404).json({ error: "Course not found" });
    if (course.instructorId === userId) return res.status(400).json({ error: "Cannot enroll in your own course" });
    if (await prisma.enrollment.findUnique({ where: { userId_courseId: { userId, courseId } } })) return res.status(400).json({ error: "Already enrolled in this course" });
    if (course.isFree) { await prisma.enrollment.create({ data: { userId, courseId, paymentStatus: "WAIVED" } }); return res.json({ message: "Successfully enrolled in free course" }); }
    if (!reference) return res.status(400).json({ error: "Payment reference required" });
    const secret = process.env.PAYSTACK_SECRET;
    if (!secret) return res.status(500).json({ error: "PAYSTACK_SECRET is not configured" });
    const verified = await axios.get(`https://api.paystack.co/transaction/verify/${reference}`, { headers: { Authorization: `Bearer ${secret}` } });
    if (verified.data?.data?.status !== "success") return res.status(400).json({ error: "Payment verification failed" });
    await prisma.enrollment.create({ data: { userId, courseId, paymentStatus: "PAID", paymentMethod: String(paymentMethod || "PAYSTACK").toUpperCase() as any, paymentReference: reference, amountPaid: Number(verified.data.data.amount || 0) } });
    res.json({ message: "Payment verified and enrollment successful", amountPaid: Number(verified.data.data.amount || 0) });
  } catch (error) { console.error("Enroll error:", error); res.status(500).json({ error: "Enrollment process failed" }); }
};

export const getUserCourses = async (req: Request, res: Response) => {
  try {
    const enrollments = await prisma.enrollment.findMany({ where: { userId: req.params.userId }, include: { course: { include: { instructor: { select: { name: true } }, category: true } } } });
    res.json(enrollments.map((e) => ({ id: e.course.id, title: e.course.title, description: e.course.description, instructor: e.course.instructor.name, thumbnail: e.course.thumbnail || "/images/course-default.jpg", price: e.course.price, isFree: e.course.isFree, level: e.course.level || "Beginner", duration: e.course.duration || "0 hours", category: e.course.category.name, progress: e.progressPercentage })));
  } catch { res.status(500).json({ error: "Unable to fetch enrolled courses" }); }
};

export const getCourseModules = async (req: Request, res: Response) => {
  try { res.json(await prisma.module.findMany({ where: { courseId: req.params.courseId }, orderBy: { order: "asc" }, include: { lessons: { orderBy: { order: "asc" } } } })); }
  catch { res.status(500).json({ error: "Failed to fetch course modules" }); }
};

export const getPublicCourses = async (req: Request, res: Response) => {
  try {
    const courses = await prisma.course.findMany({ where: { status: "PUBLISHED", OR: [{ publishAt: null }, { publishAt: { lte: new Date() } }], category: req.query.category ? { name: String(req.query.category) } : undefined }, orderBy: { createdAt: "desc" }, include: courseInclude });
    res.json(courses.map((course) => shapeCourseResponse(course)));
  } catch (error) { console.error("Error fetching public courses:", error); res.status(500).json({ error: "Failed to fetch courses" }); }
};

export const getCategories = async (_req: AuthRequest, res: Response) => { try { res.json((await prisma.category.findMany({ orderBy: { name: "asc" } })).map((category) => category.name)); } catch { res.status(500).json({ error: "Failed to fetch categories" }); } };
export const uploadThumbnail = async (req: Request, res: Response) => { if (!req.file) return res.status(400).json({ error: "No file uploaded" }); res.json({ imageUrl: `http://localhost:5000/uploads/${req.file.filename}` }); };

export const deleteCourse = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const course = await prisma.course.findUnique({ where: { id: req.params.courseId } });
    if (!course) { res.status(404).json({ error: "Course not found" }); return; }
    const role = String(req.user?.role).toUpperCase();
    if (role !== "ADMIN" && !(role === "INSTRUCTOR" && course.instructorId === req.user?.id)) { res.status(403).json({ error: "You are not authorized to delete this course" }); return; }
    await prisma.course.delete({ where: { id: course.id } });
    await prisma.auditLog.create({ data: { actorId: req.user?.id, actorRole: role, actionType: "DELETE_COURSE", resourceType: "Course", resourceId: course.id, details: { title: course.title }, ipAddress: req.ip } });
    res.json({ message: "Course deleted successfully" });
  } catch (error) { console.error("Error deleting course:", error); res.status(500).json({ error: "Failed to delete course" }); }
};

export const updateCourseStatus = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const status = String(req.body.status || "").toUpperCase() as any;
    if (!["DRAFT", "REVIEW", "QA", "PUBLISHED", "ARCHIVED"].includes(status)) { res.status(400).json({ error: "Invalid status value" }); return; }
    const course = await prisma.course.findUnique({ where: { id: req.params.courseId } });
    if (!course) { res.status(404).json({ error: "Course not found" }); return; }
    const role = String(req.user?.role).toUpperCase();
    if (role === "INSTRUCTOR" && course.instructorId !== req.user?.id) { res.status(403).json({ error: "You are not authorized to update this course" }); return; }
    if (role === "INSTRUCTOR" && !["DRAFT", "REVIEW"].includes(status)) { res.status(403).json({ error: "Instructors can only set status to DRAFT or REVIEW" }); return; }
    const updated = await prisma.course.update({ where: { id: course.id }, data: { status, reviewRequestedAt: status === "REVIEW" ? new Date() : null, publishAt: status === "PUBLISHED" ? (req.body.publishAt ? new Date(req.body.publishAt) : course.publishAt || new Date()) : course.publishAt }, include: courseInclude });
    await prisma.auditLog.create({ data: { actorId: req.user?.id, actorRole: role, actionType: "COURSE_STATUS_CHANGE", resourceType: "Course", resourceId: course.id, details: { status }, ipAddress: req.ip } });
    res.json({ message: "Course status updated", course: shapeCourseResponse(updated) });
  } catch (error) { console.error("Error updating course status:", error); res.status(500).json({ error: "Failed to update course status" }); }
};

export const updateCourse = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const course = await prisma.course.findUnique({ where: { id: req.params.courseId } });
    if (!course) { res.status(404).json({ error: "Course not found" }); return; }
    const role = String(req.user?.role).toUpperCase();
    if (role !== "ADMIN" && !(role === "INSTRUCTOR" && course.instructorId === req.user?.id)) { res.status(403).json({ error: "You are not authorized to update this course" }); return; }
    const { title, description, category, price, isFree, thumbnail, finalAssessment, level, duration, modules } = req.body;
    const categoryId = category === undefined ? course.categoryId : await categoryIdFor(category);
    const updated = await prisma.$transaction(async (tx) => {
      if (Array.isArray(modules)) await tx.module.deleteMany({ where: { courseId: course.id } });
      return tx.course.update({ where: { id: course.id }, data: { title, description, categoryId, price: price === undefined ? undefined : Number(price), isFree, thumbnail, finalAssessment, level, duration, modules: Array.isArray(modules) ? { create: modules.map(moduleData) } : undefined }, include: courseInclude });
    });
    res.json({ message: "Course updated successfully", course: shapeCourseResponse(updated) });
  } catch (error) { console.error("Error updating course:", error); res.status(500).json({ error: "Failed to update course" }); }
};

export const getEnrolledCourses = async (req: AuthRequest, res: Response) => getUserCourses({ ...req, params: { userId: req.user?.id || "" } } as unknown as Request, res);
