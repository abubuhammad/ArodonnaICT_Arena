import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../utils/api";
import { motion } from "framer-motion";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store";
import { setEnrollment as setEnrollmentAction } from "../store/slices/enrollmentSlice";
import { refreshToken } from "../store/slices/authSlice";

// Import modular components from coursepage folder
import CourseHeader from "../components/coursepage/CourseHeader";
import InstructorInfo from "../components/coursepage/InstructorInfo";
import CourseProgress from "../components/coursepage/CourseProgress";
import ModulesSection, { Module } from "../components/coursepage/ModulesSection";
import NavigationButtons from "../components/coursepage/NavigationButtons";
import LiveVideoChat from "../components/coursepage/LiveVideoChat";
import CodeExecutor from "../components/coursepage/CodeExecutor";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

interface CodeExercise {
  language: string;
  initialCode: string;
  expectedOutput?: string;
}

interface Lesson {
  _id: string;
  title: string;
  content: string;
  type: 'text' | 'code' | 'video';
  codeExercise?: CodeExercise;
  quizQuestion?: string;
  quizOptions?: string[];
  correctAnswer?: string;
  completed?: boolean;
}

interface ModuleType extends Module {
  lessons: Lesson[];
}

interface Instructor {
  _id: string;
  name: string;
  title: string;
  avatar: string;
  isAvailableForCall?: boolean;
}

interface Course {
  _id: string;
  title: string;
  description: string;
  category: string;
  instructor: Instructor;
  price: number;
  isFree: boolean;
  enrolledStudents: string[];
  modules: ModuleType[];
  thumbnail: string;
  progress?: number; // global progress if available
}

interface Enrollment {
  _id: string;
  userId: string;
  courseId: {
    _id: string;
    title: string;
  };
  status: "enrolled" | "in-progress" | "completed";
  paymentStatus: "not-paid" | "pending" | "paid";
  paymentMethod?: "paystack" | "bank-transfer";
  paymentReference?: string;
  createdAt: string;
  progressPercentage: number;
  progress?: {
    moduleId: string;
    lessons: {
      lessonId: string;
      completed: boolean;
    }[];
    completed: boolean;
  }[];
}

const CoursePage: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const navigate = useNavigate();
  const { user, token } = useSelector((state: RootState) => state.auth);
  const dispatch = useDispatch<AppDispatch>();
  const [course, setCourse] = useState<Course | null>(null);
  const [enrollment, setEnrollment] = useState<Enrollment | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [expandedModules, setExpandedModules] = useState<string[]>([]);
  const [showLiveChat, setShowLiveChat] = useState(false);
  const [showCodeExecutor, setShowCodeExecutor] = useState(false);
  const [currentCodeExercise, setCurrentCodeExercise] = useState<CodeExercise | null>(null);
  const [currentLesson, setCurrentLesson] = useState<Lesson | null>(null);
  const [modules, setModules] = useState<ModuleType[]>([]);
  const [showQuizResult, setShowQuizResult] = useState(false);
  const [quizResult, setQuizResult] = useState(false);
  const [currentModuleIndex, setCurrentModuleIndex] = useState(0);
  const [currentLessonIndex, setCurrentLessonIndex] = useState(0);
  const [showCompletionModal, setShowCompletionModal] = useState(false);
  const [nextLessonData, setNextLessonData] = useState<{ moduleIndex: number; lessonIndex: number } | null>(null);

  const goBack = () => {
    if (window.history.length > 1) navigate(-1);
    else navigate("/courses");
  };

  const goDashboard = () => navigate("/dashboard");

  // Get current module from modules array using currentModuleIndex
  const currentModule = modules[currentModuleIndex] || null;

  // Function to handle navigation to next lesson
  const navigateToNextLesson = (moduleIndex: number, lessonIndex: number) => {
    const nextModule = modules[moduleIndex];
    const nextLesson = nextModule.lessons[lessonIndex];
    setCurrentLesson(nextLesson);
    setCurrentModuleIndex(moduleIndex);
    setCurrentLessonIndex(lessonIndex);
  };

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!user || !token) {
      navigate('/login');
    }
  }, [user, token, navigate]);

  useEffect(() => {
    const fetchCourse = async () => {
      try {
        if (!courseId || !user?.id) {
          console.log("Missing courseId or user.id:", { courseId, userId: user?.id });
          return;
        }

        console.log("Fetching course data for:", courseId);
        const courseResponse = await api.get<Course>(`/courses/${courseId}`, { withCredentials: true });
        
        console.log("Raw course response:", courseResponse);
        console.log("Course data structure:", {
          hasData: !!courseResponse.data,
          hasInstructor: !!courseResponse.data?.instructor,
          instructorData: courseResponse.data?.instructor,
          fullCourseData: courseResponse.data
        });
        
        // Validate course data
        if (!courseResponse.data || !courseResponse.data.instructor) {
          throw new Error("Invalid course data: instructor information is missing");
        }
        
        console.log("Course data received:", courseResponse.data);

        const normalizedCourse = {
          ...courseResponse.data,
          modules: (courseResponse.data.modules || []).map((module: any) => ({
            ...module,
            _id: module._id || module.id,
            lessons: (module.lessons || []).map((lesson: any) => ({
              ...lesson,
              _id: lesson._id || lesson.id,
            })),
          })),
        };

        setCourse(normalizedCourse);
        setModules(normalizedCourse.modules);
        
        // Set initial lesson
        if (normalizedCourse.modules.length > 0) {
          const firstModule = normalizedCourse.modules[0];
          if (firstModule.lessons.length > 0) {
            setCurrentLesson(firstModule.lessons[0]);
          }
        }

        console.log("Fetching enrollment status for:", { courseId, userId: user.id });
        // Fetch enrollment status
        const { data: enrollment } = await api.get<Enrollment>(`/enrollments/my-courses`, { withCredentials: true });
        console.log("Enrollment data received:", enrollment);
        
        // Find the enrollment for this course
        const courseEnrollment = Array.isArray(enrollment) 
          ? enrollment.find(e => e.courseId._id === courseId)
          : null;
        
        if (courseEnrollment) {
          setEnrollment(courseEnrollment);
          dispatch(setEnrollmentAction(courseEnrollment));
        }
      } catch (error: any) {
        console.error("Error fetching course:", error);
        if (error.response?.status === 401) {
          // Try to refresh the token
          try {
            console.log("Attempting to refresh token...");
            const result = await dispatch(refreshToken()).unwrap();
            console.log("Token refresh result:", result);
            if (result.token) {
              // Retry the request after token refresh
              console.log("Retrying request with new token...");
              // Wait a moment for the Redux store to update
              setTimeout(() => {
                fetchCourse();
              }, 100);
            }
          } catch (refreshError) {
            console.error("Token refresh failed:", refreshError);
            // If refresh fails, redirect to login
            navigate('/login');
          }
        } else if (error.response?.status === 404) {
          // Course or enrollment not found, this is normal for non-enrolled users
          setEnrollment(null);
          dispatch(setEnrollmentAction(null));
        } else {
          setError("Failed to load course information. Please try again.");
        }
      } finally {
        setLoading(false);
      }
    };

    fetchCourse();
  }, [courseId, user, token, navigate, dispatch]);

  const toggleModule = (moduleId: string) => {
    setExpandedModules((prev) =>
      prev.includes(moduleId)
        ? prev.filter((id) => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  // Helper: Compute next lesson based on enrollment progress.
  // This assumes enrollment.progress is a percentage (0-100) of total lessons completed.
  const computeNextLesson = (): { moduleId: string; lessonIndex: number } | null => {
    if (!course) return null;
    const totalLessons = course.modules.reduce(
      (total, module) => total + module.lessons.length,
      0
    );
    // Use enrollment progress if exists, else default to 0%
    const progressValue = enrollment ? enrollment.progressPercentage : (course.progress || 0);
    const lessonsCompleted = Math.floor((progressValue / 100) * totalLessons);
    let cumulative = 0;
    for (const mod of course.modules) {
      if (cumulative + mod.lessons.length > lessonsCompleted) {
        return { moduleId: mod._id, lessonIndex: lessonsCompleted - cumulative };
      }
      cumulative += mod.lessons.length;
    }
    // If progress is 100% or no matching lesson, return the last lesson of the last module.
    const lastModule = course.modules[course.modules.length - 1];
    return { moduleId: lastModule._id, lessonIndex: lastModule.lessons.length - 1 };
  };

  const startLesson = (moduleId: string, lessonIndex: number) => {
    // Find the module from the current course data.
    const currentModule = course?.modules.find((mod) => mod._id === moduleId);
    if (currentModule) {
      // Get the lesson using the lesson index.
      const lesson = currentModule.lessons[lessonIndex];
      // Navigate to the lesson page, passing the lesson data in state.
      navigate(`/courses/${courseId}/modules/${moduleId}/lessons/${lessonIndex}`, { state: { lesson } });
    } else {
      // Fallback: navigate without lesson data.
      navigate(`/courses/${courseId}/modules/${moduleId}/lessons/${lessonIndex}`);
    }
  };
  

  const startAssessment = (moduleId: string) => {
    navigate(`/courses/${courseId}/modules/${moduleId}/assessment`);
  };

  const handleBack = () => {
    navigate("/courses");
  };

  const handleStartLearning = () => {
    if (course) {
      if (enrollment) {
        // Continue from where the student left off.
        const nextLesson = computeNextLesson();
        if (nextLesson) {
          startLesson(nextLesson.moduleId, nextLesson.lessonIndex);
        } else if (course.modules.length > 0 && course.modules[0].lessons.length > 0) {
          startLesson(course.modules[0]._id, 0);
        }
      } else {
        // For new enrollees, start at the beginning.
        if (course.modules.length > 0 && course.modules[0].lessons.length > 0) {
          startLesson(course.modules[0]._id, 0);
        }
      }
    }
  };

  // Show live chat if instructor is available or upon student request.
  const handleLiveChat = () => {
    setShowLiveChat(true);
  };

  const handleCodeExercise = (exercise: CodeExercise | undefined) => {
    if (exercise) {
      setCurrentCodeExercise(exercise);
      setShowCodeExecutor(true);
    }
  };

  const handleQuizSubmit = async (moduleId: string, lessonIndex: number) => {
    if (!currentLesson || !currentLesson.quizQuestion || !currentLesson.quizOptions || !currentLesson.correctAnswer) {
      return;
    }

    const selectedAnswer = document.querySelector(`input[name="quiz-${currentLesson._id}"]:checked`) as HTMLInputElement;
    if (!selectedAnswer) {
      setError("Please select an answer");
      return;
    }

    const isCorrect = selectedAnswer.value === currentLesson.correctAnswer;
    setShowQuizResult(true);
    setQuizResult(isCorrect);

    if (isCorrect) {
      // Submit quiz attempt to backend and, on pass, mark lesson complete
      try {
        if (!enrollment) throw new Error('No enrollment');
        const resp = await api.post(
          `/enrollments/${enrollment._id}/quizzes/${currentLesson?._id}/submit`,
          { answers: [selectedAnswer] },
          { withCredentials: true }
        );
        const result = resp.data?.result || resp.data;
        const passed = result?.status === 'PASSED' || result?.status === 'GRADED' || result?.status === 'AWAITING_MANUAL_REVIEW';
        if (passed) {
          // Refresh enrollment list and update local enrollment
          const { data: enrollments } = await api.get(`/enrollments/my-courses`, { withCredentials: true });
          const updatedEnrollment = Array.isArray(enrollments) ? enrollments.find((e: any) => e.courseId._id === courseId) : null;
          if (updatedEnrollment) {
            setEnrollment(updatedEnrollment);
            dispatch(setEnrollmentAction(updatedEnrollment));
          }

          // Update local modules copy
          const updatedModules = modules.map(module => {
            if (module._id === moduleId) {
              const updatedLessons = [...module.lessons];
              updatedLessons[lessonIndex] = {
                ...updatedLessons[lessonIndex],
                completed: true
              };
              return { ...module, lessons: updatedLessons };
            }
            return module;
          });
          setModules(updatedModules);

          // Navigate to next lesson if available
          const currentModuleIndex = modules.findIndex(m => m._id === moduleId);
          const currentModule = modules[currentModuleIndex];
          if (lessonIndex < currentModule.lessons.length - 1) {
            setCurrentLesson(currentModule.lessons[lessonIndex + 1]);
            setShowQuizResult(false);
          } else if (currentModuleIndex < modules.length - 1) {
            const nextModule = modules[currentModuleIndex + 1];
            setCurrentLesson(nextModule.lessons[0]);
            setShowQuizResult(false);
          }
        }
      } catch (err) {
        console.error('Quiz submit error', err);
        setError('Failed to submit quiz. Please try again.');
      }
    }
  };

  const handleNextLesson = async () => {
    if (!currentModule || !currentLesson) return;

    const currentModuleIndex = modules.findIndex(m => m._id === currentModule._id);
    const currentLessonIndex = currentModule.lessons.findIndex(l => l._id === currentLesson._id);

    // Check if there are more lessons in the current module
    if (currentLessonIndex < currentModule.lessons.length - 1) {
      const nextLesson = currentModule.lessons[currentLessonIndex + 1];
      setCurrentLesson(nextLesson);
      setCurrentLessonIndex(currentLessonIndex + 1);
      return;
    }

    // If we're at the last lesson of the current module
    if (currentModuleIndex < modules.length - 1) {
      const nextModule = modules[currentModuleIndex + 1];
      const nextLesson = nextModule.lessons[0];
      setCurrentLesson(nextLesson);
      setCurrentModuleIndex(currentModuleIndex + 1);
      setCurrentLessonIndex(0);
      return;
    }

    // If we're at the last lesson of the last module
    navigate('/dashboard');
  };

  const handleMarkAsComplete = async () => {
    if (!currentLesson || !currentModule || !enrollment) return;

    try {
      // Call the new lesson completion endpoint
      await api.post(
        `/enrollments/${enrollment._id}/lessons/${currentLesson._id}/complete`,
        { moduleId: currentModule._id },
        { withCredentials: true }
      );

      // Refresh enrollment list and update local enrollment
      const { data: enrollments } = await api.get(`/enrollments/my-courses`, { withCredentials: true });
      const updatedEnrollment = Array.isArray(enrollments) ? enrollments.find((e: any) => e.courseId._id === courseId) : null;
      if (updatedEnrollment) {
        setEnrollment(updatedEnrollment);
        dispatch(setEnrollmentAction(updatedEnrollment));
      }

      // Show completion modal
      setShowCompletionModal(true);

      // Calculate next lesson data
      const currentModuleIndex = modules.findIndex(m => m._id === currentModule._id);
      const currentLessonIndex = currentModule.lessons.findIndex(l => l._id === currentLesson._id);

      let nextModuleIndex = currentModuleIndex;
      let nextLessonIndex = currentLessonIndex + 1;

      if (currentLessonIndex === currentModule.lessons.length - 1) {
        nextModuleIndex = currentModuleIndex + 1;
        nextLessonIndex = 0;
      }

      setNextLessonData({ moduleIndex: nextModuleIndex, lessonIndex: nextLessonIndex });
    } catch (error) {
      console.error("Error marking lesson as complete:", error);
      setError("Failed to mark lesson as complete. Please try again.");
    }
  };

  // Add the completion modal component
  const CompletionModal = () => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-8 max-w-md w-full mx-4">
        <h3 className="text-2xl font-bold text-center mb-4">Well done! 🎉</h3>
        <p className="text-center mb-6">You've completed this lesson successfully. You can proceed to the next lesson.</p>
        <div className="flex justify-center">
          <button
            onClick={() => {
              setShowCompletionModal(false);
              if (nextLessonData) {
                navigateToNextLesson(nextLessonData.moduleIndex, nextLessonData.lessonIndex);
              }
            }}
            className="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition-colors"
          >
            Next Lesson
          </button>
        </div>
      </div>
    </div>
  );

  if (loading) {
    return (
      <motion.div
        className="flex justify-center items-center h-screen"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600"></div>
      </motion.div>
    );
  }

  if (error || !course) {
    return (
      <motion.div
        className="flex justify-center items-center h-screen"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <p className="text-red-500 text-lg font-semibold">{error}</p>
      </motion.div>
    );
  }

  // Calculate the total number of lessons.
  const totalLessons = course.modules.reduce(
    (total, module) => total + module.lessons.length,
    0
  );
  // Use the enrollment progress if available; otherwise, default to course.progress (or 0).
  const displayedProgress = enrollment ? enrollment.progressPercentage : (course.progress || 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 pt-6 flex items-center gap-4">
        <button
          onClick={goBack}
          className="text-sm text-indigo-600 hover:text-indigo-700 flex items-center gap-2"
        >
          ← Back
        </button>
        <button
          onClick={goDashboard}
          className="text-sm text-gray-700 hover:text-gray-900 flex items-center gap-2"
        >
          ← Back to Dashboard
        </button>
      </div>
      <motion.div
        className="max-w-4xl mx-auto p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <CourseHeader
          title={course.title}
          description={course.description}
          totalLessons={totalLessons}
          progress={displayedProgress}
        />

        {course.instructor && <InstructorInfo instructor={course.instructor} />}

        <CourseProgress progress={displayedProgress} />

        {currentLesson && (
          <div className="mt-4 flex flex-wrap gap-3">
            <button
              onClick={handleMarkAsComplete}
              className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              Mark Current Lesson Complete
            </button>
            <button
              onClick={handleNextLesson}
              className="px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200 transition-colors"
            >
              Next Lesson
            </button>
          </div>
        )}

        {/* Live Video Chat Button (if instructor is available) */}
        {course?.instructor?.isAvailableForCall && (
          <button
            onClick={handleLiveChat}
            className="mt-4 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            Join Live Video Call
          </button>
        )}

        <ModulesSection
          modules={course.modules}
          expandedModules={expandedModules}
          toggleModule={toggleModule}
          startLesson={startLesson}
          startAssessment={startAssessment}
          onCodeExercise={handleCodeExercise}
        />

        <NavigationButtons
          onBack={handleBack}
          onStartLearning={handleStartLearning}
          showStartLearning={
            course.modules.length > 0 && course.modules[0].lessons.length > 0
          }
        />

        {showLiveChat && (
          <LiveVideoChat
            roomId={`course-${course._id}`}
            onClose={() => setShowLiveChat(false)}
          />
        )}

        {showCodeExecutor && currentCodeExercise && (
          <CodeExecutor
            language={currentCodeExercise.language}
            initialCode={currentCodeExercise.initialCode}
            onClose={() => {
              setShowCodeExecutor(false);
              setCurrentCodeExercise(null);
            }}
          />
        )}

        {currentLesson && currentLesson.quizQuestion && currentLesson.quizOptions && (
          <div className="bg-white rounded-lg shadow-md p-6 mb-6">
            <h3 className="text-xl font-semibold mb-4">Quiz</h3>
            <p className="text-gray-700 mb-4">{currentLesson.quizQuestion}</p>
            <div className="space-y-3">
              {currentLesson.quizOptions.map((option, index) => (
                <label key={index} className="flex items-center space-x-3">
                  <input
                    type="radio"
                    name={`quiz-${currentLesson._id}`}
                    value={option}
                    className="text-purple-600"
                  />
                  <span className="text-gray-700">{option}</span>
                </label>
              ))}
            </div>
            {showQuizResult ? (
              <div className={`mt-4 p-4 rounded-lg ${quizResult ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                {quizResult ? (
                  <div>
                    <p className="font-semibold">Correct! Well done!</p>
                    <p className="text-sm mt-2">You can now proceed to the next lesson.</p>
                  </div>
                ) : (
                  <div>
                    <p className="font-semibold">Incorrect. Please try again.</p>
                    <p className="text-sm mt-2">Review the lesson content and try the quiz again.</p>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => handleQuizSubmit(currentModule._id, currentLessonIndex)}
                className="mt-4 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
              >
                Submit Answer
              </button>
            )}
          </div>
        )}

        {/* Add the completion modal */}
        {showCompletionModal && <CompletionModal />}
      </motion.div>

      {currentModule && (
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-4xl mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-8">
              {currentModule.title}
            </h1>
            {/* ... rest of the JSX ... */}
          </div>
        </div>
      )}
    </div>
  );
};

export default CoursePage;