// src/pages/CourseLearnPage.tsx
import React from 'react';
import { useParams } from 'react-router-dom';

const CourseLearnPage: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();

  return (
    <div>
      <h1>Course Learning Page</h1>
      <p>Course ID: {courseId}</p>
      {/* Add your learning content here */}
    </div>
  );
};

export default CourseLearnPage;
