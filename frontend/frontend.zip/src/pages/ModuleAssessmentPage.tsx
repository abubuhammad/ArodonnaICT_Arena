// src/pages/ModuleAssessmentPage.tsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { motion } from "framer-motion";

interface AssessmentQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
}

interface Assessment {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  passingScore: number;
  questions: AssessmentQuestion[];
  completed: boolean;
  score?: number;
}

interface Module {
  _id: string;
  title: string;
  description: string;
  order: number;
  assessment: Assessment | null;
}

interface Course {
  _id: string;
  title: string;
  modules: Module[];
}

const ModuleAssessmentPage: React.FC = () => {
  const { courseId, moduleId } = useParams<{ courseId: string; moduleId: string }>();
  const navigate = useNavigate();
  const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";
  
  const [moduleData, setModuleData] = useState<Module | null>(null);
  const [courseData, setCourseData] = useState<Course | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([]);
  const [score, setScore] = useState<number | null>(null);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetchModuleAssessment = async () => {
      if (!courseId || !moduleId) return;
      try {
        const token = localStorage.getItem("token");
        // Fetch the entire course details (including modules)
        const response = await axios.get(`${API_URL}/courses/${courseId}`, {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        });
        const course: Course = response.data;
        setCourseData(course);
        const mod: Module | undefined = (course.modules || []).find(
          (m: Module) => m._id === moduleId
        );
        if (mod) {
          setModuleData(mod);
          // Initialize answers array with empty strings if assessment exists
          if (mod.assessment) {
            const qLen = (mod.assessment.questions && mod.assessment.questions.length) || 0;
            setSelectedAnswers(new Array(qLen).fill(""));
          }
        }
      } catch (err) {
        console.error("Error fetching module assessment:", err);
        setError("Failed to load assessment. Please try again.");
      }
    };
    fetchModuleAssessment();
  }, [courseId, moduleId]);

  const handleAnswerSelect = (questionIndex: number, answer: string) => {
    setSelectedAnswers((prev) => {
      const updated = [...prev];
      updated[questionIndex] = answer;
      return updated;
    });
  };

  const calculateScore = (): number => {
    if (!moduleData?.assessment) return 0;
    let correctCount = 0;
    const questions = moduleData.assessment.questions || [];
    questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswer) {
        correctCount += 1;
      }
    });
    if (questions.length === 0) return 0;
    return Math.round((correctCount / questions.length) * 100);
  };

  const handleSubmitAssessment = async () => {
    if (!moduleData?.assessment) return;
    const calculatedScore = calculateScore();
    setScore(calculatedScore);
    if (calculatedScore < moduleData.assessment.passingScore) {
      setError("Your score is below the passing threshold. Please try again.");
      return;
    }
    // If passed, update module progress on backend
      try {
      const token = localStorage.getItem("token");
      await axios.post(
        `${API_URL}/enrollments/update-module-progress`,
        {
          courseId,
          moduleId,
          assessmentPassed: true,
          score: calculatedScore,
        },
        { headers: { Authorization: `Bearer ${token}` }, withCredentials: true }
      );
      // Navigate to next module's first lesson if available
      if (courseData && moduleData) {
        // Find the next module by order
        const nextModule = (courseData.modules || [])
          .filter((m) => m.order > moduleData.order)
          .sort((a, b) => a.order - b.order)[0];
        if (nextModule) {
          navigate(`/courses/${courseId}/modules/${nextModule._id}/lessons/0`);
          return;
        }
      }
      // If no next module, navigate to course learning page
      navigate(`/courses/${courseId}/learn`);
    } catch (err) {
      console.error("Error updating module progress", err);
      const serverMessage = (err as any)?.response?.data?.error || (err as any)?.message;
      setError(serverMessage || "Failed to update progress. Please try again later.");
    }
  };

  return (
    <motion.div
      className="min-h-screen bg-gray-50 flex items-center justify-center p-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="bg-white p-8 rounded-lg shadow-md max-w-xl w-full">
        <h2 className="text-2xl font-bold mb-4">Module Assessment</h2>
        {error && (
          <p className="text-red-500 mb-4">{error}</p>
        )}
        {moduleData?.assessment ? (
          <>
            <p className="mb-4">{moduleData.assessment.description}</p>
            {(moduleData.assessment.questions || []).map((q, idx) => (
              <div key={idx} className="mb-4 border p-4 rounded">
                <p className="font-semibold">{q.question}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {(q.options || []).map((option) => (
                    <button
                      key={option}
                      onClick={() => handleAnswerSelect(idx, option)}
                      className={`px-3 py-1 border rounded ${
                        selectedAnswers[idx] === option ? "bg-blue-200" : ""
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <button
              onClick={handleSubmitAssessment}
              className="w-full px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50"
              disabled={selectedAnswers.includes("")}
            >
              Submit Assessment
            </button>
            {score !== null && (
              <p className="mt-4">Your score: {score}%</p>
            )}
          </>
        ) : (
          <p>No assessment available for this module.</p>
        )}
      </div>
    </motion.div>
  );
};

export default ModuleAssessmentPage;
