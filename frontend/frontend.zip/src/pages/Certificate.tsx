import React from "react";
import { useParams } from "react-router-dom";

const Certificate = () => {
  const { name, course } = useParams();

  return (
    <div>
      <h2>Congratulations, {name}!</h2>
      <p>You have successfully completed the course: {course}</p>
      <button onClick={() => window.print()}>Download Certificate</button>
    </div>
  );
};

export default Certificate;
