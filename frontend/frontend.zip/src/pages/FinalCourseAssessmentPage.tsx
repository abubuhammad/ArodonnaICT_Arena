// src/pages/FinalCourseAssessmentPage.tsx
import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { motion } from "framer-motion";

interface AssessmentQuestion {
  question: string;
  options: string[];
  correctAnswer: string;
}

interface FinalAssessment {
  id: string;
  title: string;
  description: string;
  timeLimit: number;
  passingScore: number;
  questions: AssessmentQuestion[];
  completed: boolean;
  score?: number;
}

interface Course {
  _id: string;
  title: string;
  finalAssessment: FinalAssessment;
  // other fields...
}

const FinalCourseAssessmentPage: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const navigate = useNavigate();
  
  const [assessment, setAssessment] = useState<FinalAssessment | null>(null);
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([]);
  const [score, setScore] = useState<number | null>(null);
  const [error, setError] = useState<string>("");

  useEffect(() => {
    const fetchFinalAssessment = async () => {
      if (!courseId) return;
      try {
        const token = localStorage.getItem("token");
        // Assuming your course endpoint returns the finalAssessment data.
        const response = await axios.get<Course>(`/api/courses/${courseId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const course: Course = response.data;
        if (course.finalAssessment) {
          setAssessment(course.finalAssessment);
          setSelectedAnswers(new Array(course.finalAssessment.questions.length).fill(""));
        }
      } catch (error) {
        console.error("Error fetching final assessment:", error);
        setError("Failed to load final assessment. Please try again.");
      }
    };
    fetchFinalAssessment();
  }, [courseId]);

  const handleAnswerSelect = (index: number, answer: string) => {
    setSelectedAnswers(prev => {
      const updated = [...prev];
      updated[index] = answer;
      return updated;
    });
  };

  const calculateScore = () => {
    if (!assessment) return 0;
    let correctCount = 0;
    assessment.questions.forEach((q, idx) => {
      if (selectedAnswers[idx] === q.correctAnswer) {
        correctCount++;
      }
    });
    return Math.round((correctCount / assessment.questions.length) * 100);
  };

  const handleSubmitFinalAssessment = async () => {
    if (!assessment) return;
    const calculatedScore = calculateScore();
    setScore(calculatedScore);
    if (calculatedScore < assessment.passingScore) {
      setError("Your score is below the passing threshold. Please try again.");
      return;
    }
    try {
      const token = localStorage.getItem("token");
      const API_URL = process.env.REACT_APP_API_URL || '';
      await axios.post(
        `${API_URL || ''}/enrollments/update-final-assessment`,
        {
          courseId,
          finalScore: calculatedScore,
          passingScore: assessment.passingScore,
        },
        { headers: { Authorization: `Bearer ${token}` }, withCredentials: true }
      );
      // Navigate to certificate view page after passing final assessment.
      navigate(`/courses/${courseId}/certificate`);
    } catch (err) {
      console.error("Error updating final assessment:", err);
      setError("Failed to update final assessment. Please try again later.");
    }
  };

  return (
    <motion.div
      className="min-h-screen bg-gray-50 flex items-center justify-center p-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="bg-white p-8 rounded-lg shadow-md max-w-xl w-full">
        <h2 className="text-2xl font-bold mb-4">Final Course Assessment</h2>
        {error && <p className="text-red-500 mb-4">{error}</p>}
        {assessment ? (
          <>
            <p className="mb-4">{assessment.description}</p>
            {assessment.questions.map((q, idx) => (
              <div key={idx} className="mb-4 border p-4 rounded">
                <p className="font-semibold">{q.question}</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {q.options.map((option) => (
                    <button
                      key={option}
                      onClick={() => handleAnswerSelect(idx, option)}
                      className={`px-3 py-1 border rounded ${
                        selectedAnswers[idx] === option ? "bg-blue-200" : ""
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>
            ))}
            <button
              onClick={handleSubmitFinalAssessment}
              className="w-full px-4 py-2 bg-green-600 text-white rounded disabled:opacity-50"
              disabled={selectedAnswers.includes("")}
            >
              Submit Final Assessment
            </button>
            {score !== null && <p className="mt-4">Your score: {score}%</p>}
          </>
        ) : (
          <p>No final assessment available.</p>
        )}
      </div>
    </motion.div>
  );
};

export default FinalCourseAssessmentPage;
