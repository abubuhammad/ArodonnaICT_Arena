// src/components/sections/HeroSection.tsx
import React from 'react';
import { motion } from 'framer-motion';
import { HeroSectionProps } from '../../types';

const HeroSection: React.FC<HeroSectionProps> = ({
  title,
  description,
  primaryButtonText,
  secondaryButtonText,
  onPrimaryClick,
  onSecondaryClick,
  imageUrl
}) => {
  return (
    <section className="relative min-h-screen flex items-center overflow-hidden">
      {/* Dazzling animated gradient background */}
      <div className="absolute inset-0 z-0">
        {/* Animated gradient base */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 animate-pulse" />
        
        {/* Animated gradient overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-tl from-cyan-400 via-violet-500 to-indigo-600 opacity-80" />
        
        {/* Floating gradient orbs for visual interest */}
        <div className="absolute top-20 left-20 w-64 h-64 bg-gradient-to-r from-pink-400 to-violet-400 rounded-full mix-blend-multiply filter blur-2xl opacity-70 animate-float" />
        <div className="absolute top-40 right-20 w-72 h-72 bg-gradient-to-r from-cyan-300 to-blue-400 rounded-full mix-blend-multiply filter blur-2xl opacity-60 animate-float-delayed" />
        <div className="absolute bottom-20 left-40 w-80 h-80 bg-gradient-to-r from-indigo-400 to-purple-400 rounded-full mix-blend-multiply filter blur-2xl opacity-50 animate-float-slow" />
        
        {/* Subtle text readability enhancement - much lighter */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/20 via-transparent to-transparent" />
      </div>

      {/* Animated background pattern */}
      <div className="absolute inset-0 z-0 opacity-10 pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 25% 25%, white 2px, transparent 2px)`,
          backgroundSize: '60px 60px',
          animation: 'movePattern 20s linear infinite'
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Left: Enhanced Copy with better animations */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-white z-10"
          >
            {/* Enhanced status badge with glow */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/20 border border-white/30 backdrop-blur-md mb-6 shadow-lg shadow-purple-500/20"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-sm font-medium">Trusted by 50,000+ learners worldwide</span>
              <span className="text-xs bg-emerald-400 text-emerald-900 px-2 py-1 rounded-full font-bold">NEW</span>
            </motion.div>

            {/* Enhanced title with gradient text */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              className="text-5xl md:text-7xl font-black leading-tight tracking-tight mb-6"
            >
              <span className="bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
                {title}
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-lg md:text-xl text-white/95 max-w-xl mb-10 leading-relaxed"
            >
              {description}
            </motion.p>

            {/* Enhanced buttons with better hover effects */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="flex flex-wrap gap-4 mb-12"
            >
              <button
                onClick={onPrimaryClick}
                className="group px-8 py-4 rounded-2xl font-bold text-lg bg-white text-purple-700 hover:bg-purple-50 shadow-2xl shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-300 hover:scale-105 hover:-translate-y-1"
              >
                <span className="flex items-center gap-2">
                  {primaryButtonText}
                  <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </span>
              </button>
              <button
                onClick={onSecondaryClick}
                className="px-8 py-4 rounded-2xl font-bold text-lg border-2 border-white/60 text-white hover:bg-white/10 backdrop-blur-sm transition-all duration-300 hover:scale-105 hover:border-white/80"
              >
                {secondaryButtonText}
              </button>
            </motion.div>

            {/* Enhanced stats with glassmorphism */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="grid grid-cols-3 gap-6"
            >
              {[
                { label: 'Active Students', value: '50k+', icon: '👨‍🎓' },
                { label: 'Courses', value: '500+', icon: '📚' },
                { label: 'Success Rate', value: '95%', icon: '🎯' },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.6, delay: 0.7 + index * 0.1 }}
                  className="group p-4 rounded-2xl bg-white/15 border border-white/30 backdrop-blur-md hover:bg-white/20 transition-all duration-300 cursor-pointer hover:scale-105"
                >
                  <div className="text-2xl mb-1">{stat.icon}</div>
                  <div className="text-2xl md:text-3xl font-black text-white mb-1">{stat.value}</div>
                  <div className="text-xs md:text-sm text-white/90 font-medium">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>

          {/* Right: Enhanced Image with better effects */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8, rotateY: 10 }}
            animate={{ opacity: 1, scale: 1, rotateY: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
            className="hidden md:block"
          >
            <div className="relative">
              {/* Glowing ring effect */}
              <div className="absolute -inset-6 rounded-[32px] bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 blur-2xl opacity-60 animate-pulse" />
              <div className="absolute -inset-3 rounded-[28px] bg-gradient-to-r from-white/40 to-purple-300/40 blur-lg" />
              
              {/* Image container with better styling */}
              <div className="relative rounded-[24px] ring-2 ring-white/50 overflow-hidden shadow-2xl shadow-purple-500/20 hover:shadow-purple-500/30 transition-all duration-500 hover:scale-105">
                <img
                  src={imageUrl || '/images/mainhero.jpeg'}
                  alt="Transform your tech career with our learning platform"
                  className="block w-full h-full object-cover"
                />
                {/* Gradient overlay on image for better integration */}
                <div className="absolute inset-0 bg-gradient-to-t from-purple-900/20 via-transparent to-blue-900/20 mix-blend-overlay" />
              </div>

              {/* Floating elements for visual interest */}
              <div className="absolute -top-4 -right-4 w-16 h-16 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full shadow-lg shadow-cyan-500/30 animate-float" />
              <div className="absolute -bottom-6 -left-6 w-12 h-12 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full shadow-lg shadow-pink-500/30 animate-float-delayed" />
            </div>
          </motion.div>
        </div>
      </div>

      {/* Add the required animations to your CSS or Tailwind config */}
      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        @keyframes float-delayed {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-15px); }
        }
        @keyframes float-slow {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        @keyframes movePattern {
          0% { transform: translateX(0) translateY(0); }
          100% { transform: translateX(60px) translateY(60px); }
        }
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        .animate-float-delayed {
          animation: float-delayed 8s ease-in-out infinite;
        }
        .animate-float-slow {
          animation: float-slow 10s ease-in-out infinite;
        }
      `}</style>
    </section>
  );
};

export default HeroSection;