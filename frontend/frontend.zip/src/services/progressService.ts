import axios from './axios';

export interface LessonProgress {
  lessonId: string;
  title?: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'PASSED' | 'FAILED' | 'LOCKED';
  attempts: number;
  bestScore?: number;
  lastViewedAt?: string;
  completedAt?: string;
}

export interface ModuleProgress {
  moduleId: string;
  title?: string;
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'PASSED' | 'LOCKED';
  bestScore?: number;
  assessmentPassed?: boolean;
  lessons: LessonProgress[];
}

export interface EnrollmentProgress {
  enrollmentId: string;
  status: 'ENROLLED' | 'IN_PROGRESS' | 'COMPLETED';
  progressPercentage: number;
  modules: ModuleProgress[];
}

/**
 * Fetch enrollment progress from the API.
 * Used to drive UI state for lesson locks, tick marks, and gating logic.
 */
export async function getEnrollmentProgress(enrollmentId: string): Promise<EnrollmentProgress> {
  try {
    const response = await axios.get(`/api/enrollments/${enrollmentId}/progress`);
    return response.data;
  } catch (error) {
    console.error('Failed to fetch enrollment progress:', error);
    throw error;
  }
}

/**
 * Helper: Check if a lesson is locked (status === LOCKED).
 */
export function isLessonLocked(lesson: LessonProgress): boolean {
  return lesson.status === 'LOCKED';
}

/**
 * Helper: Check if a lesson is passed and can be navigated past.
 */
export function isLessonPassed(lesson: LessonProgress): boolean {
  return lesson.status === 'PASSED';
}

/**
 * Helper: Get remaining attempts for a lesson quiz.
 */
export function getAttemptsRemaining(lesson: LessonProgress, maxAttempts: number = 3): number {
  return Math.max(0, maxAttempts - lesson.attempts);
}

/**
 * Helper: Check if all lessons in a module are passed.
 */
export function areAllLessonsPassed(module: ModuleProgress): boolean {
  return module.lessons.every(l => isLessonPassed(l));
}
